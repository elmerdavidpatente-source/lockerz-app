LOCKERZ Android app (Expo WebView wrapper) -> loads https://lockerz-ea.pages.dev

1. expo.dev -> your account -> Projects -> Create project (slug: lockerz).
   Copy its Project ID into app.json -> expo.extra.eas.projectId.
2. Upload all these files to a new GitHub repo (App.js, app.json, eas.json, package.json, assets/).
3. expo.dev -> project -> GitHub -> connect repo -> Builds -> Create build
   -> Platform Android, Profile "preview" -> wait -> download the .apk.
To open a different page on launch, edit START_URL in App.js.
